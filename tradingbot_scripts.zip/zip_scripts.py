import os
import zipfile

# Define the folder containing your scripts
folder_path = r"C:\Users\gill_\OneDrive\Documents\tradingbot"
zip_file_name = "tradingbot_scripts.zip"

# Create a zip file
zip_path = os.path.join(folder_path, zip_file_name)
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for file in os.listdir(folder_path):
        if file.endswith(".py"):  # Only add Python files
            zipf.write(os.path.join(folder_path, file), file)

print(f"All Python scripts have been zipped into {zip_file_name}")
